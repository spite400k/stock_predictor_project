import os
import pandas as pd
from supabase import create_client, Client
from dotenv import load_dotenv

# .env ファイルの読み込み
load_dotenv()

# Supabase の接続情報
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

# Supabase クライアントの作成
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def pretreatment():
    # 取得したデータを DataFrame に変換
    data = fetch_stock_data()

    if data:
        df = pd.DataFrame(data)

        # 日付データの変換
        df["insert_time"] = pd.to_datetime(df["insert_time"])
        df["update_time"] = pd.to_datetime(df["update_time"])

        # 在庫ステータスを数値に変換
        df["stock_status"] = df["stock_status"].astype(int)

        # 曜日・月などの特徴量追加
        df["day_of_week"] = df["insert_time"].dt.dayofweek
        df["month"] = df["insert_time"].dt.month

        # データ確認
        print(df.head())

        # データ挿入関数を呼び出す
        insert_stock_data(df)
    else:
        print("データ取得に失敗しました。")

# Supabase から在庫データ取得
def fetch_stock_data():
    response = supabase.table("stock_history").select("*").limit(2).execute()

    # 🔍 レスポンスのデバッグ
    print(f"レスポンスの型: {type(response)}")
    print(f"レスポンスの内容: {response}")

    # `response.data` が空でないかチェック
    if response.data:
        return response.data
    else:
        print("データが取得できませんでした。")
        return []

# 新しいデータを追加する関数
def insert_stock_data(df):
    """DataFrame のデータを Supabase の `stock_history_pretreatment` テーブルに挿入"""
    
    # 日付データを文字列に変換
    df["insert_time"] = df["insert_time"].astype(str)
    df["update_time"] = df["update_time"].astype(str)

    # DataFrame を辞書のリストに変換
    records = df.to_dict(orient="records")

    # Supabase にデータを一括挿入
    response = supabase.table("stock_history_pretreatment").insert(records).execute()

    # Supabase のレスポンス構造を確認
    if "data" in response and response.data:
        print("データの挿入が完了しました。")
        return response.data
    else:
        print(f"データ取得エラー: {response}")
        return None

# 実行テスト
if __name__ == "__main__":
    pretreatment()
