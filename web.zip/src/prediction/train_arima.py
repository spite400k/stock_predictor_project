import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

# データ読み込み
df = pd.read_csv("stock_data.csv", parse_dates=["update_time"], index_col="update_time")

# ARIMAモデルの学習
model = ARIMA(df["stock_status"], order=(5,1,0))
model_fit = model.fit()
df["forecast"] = model_fit.predict(start=len(df), end=len(df)+10)

# 予測結果を保存
df.to_csv("stock_forecast.csv")
