CREATE TABLE stock_history (
    id SERIAL PRIMARY KEY,
    product_id VARCHAR(50),
    product_name VARCHAR(255),
    description  VARCHAR(5000),
    site VARCHAR(20),
    seller_site VARCHAR(50),
    stock_status BOOLEAN,
    price INT,
    insert_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE stock_history_pretreatment (
    id SERIAL PRIMARY KEY,
    product_id VARCHAR(50),
    product_name VARCHAR(255),
    description  VARCHAR(5000),
    site VARCHAR(20),
    seller_site VARCHAR(50),
    stock_status BOOLEAN,
    price INT,
    day_of_week INT,
    month INT,
    insert_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
