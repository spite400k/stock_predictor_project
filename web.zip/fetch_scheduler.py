import datetime
import time
from src.database.supabase_insert import insert_stock_data
# from data_acquisition.fetch_amazon import fetch_amazon_stock
from src.data_acquisition.fetch_rakuten import fetch_rakuten_stock
from src.data_acquisition.fetch_yahoo import fetch_yahoo_stock
from logger import log_info, log_response  # インポート

# while True:
# amazon_data = fetch_amazon_stock()
amazon_data = [{"product_name": "PS5", "site": "Amazon", "stock_status": True}]
# レスポンスをログファイルに保存
log_response("amazon_data",amazon_data)
#insert_stock_data(amazon_data)

timestamp = datetime.datetime.now().isoformat()
print(f"{timestamp} 📦 amazon在庫データ更新完了")
log_info(f" 📦 amazon在庫データ更新完了")

rakuten_data = fetch_rakuten_stock()
# レスポンスをログファイルに保存
log_response("rakuten_data",rakuten_data)
insert_stock_data(rakuten_data)

timestamp = datetime.datetime.now().isoformat()
print(f"{timestamp}  📦 rakuten在庫データ更新完了")
log_info(f" 📦 rakuten在庫データ更新完了")

yahoo_data = fetch_yahoo_stock()
# レスポンスをログファイルに保存
log_response("yahoo_data",yahoo_data)
insert_stock_data(yahoo_data)

timestamp = datetime.datetime.now().isoformat()
print(f"{timestamp}  📦 yahoo在庫データ更新完了")
log_info(f" 📦 yahoo在庫データ更新完了")

timestamp = datetime.datetime.now().isoformat()
print(f"{timestamp}  📦 すべての在庫データ更新完了")
print("-" * 50 + "\n")
log_info(f" 📦 すべての在庫データ更新完了")
log_info("-" * 50 + "\n")

# time.sleep(3600)  # 1時間ごとに実行
